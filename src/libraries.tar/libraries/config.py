class Config:
    # 机器人QQ号
    bot_id = '123456789'
    # Bot的超级管理员
    superuser = ['1234567890']